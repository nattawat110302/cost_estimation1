const datas = [
  { id: 1000000001, name: "Somchai Madee", age: 20 },
  { id: 1000000002, name: "Sompon Madee", age: 21 },
  { id: 1000000003, name: "Sakorn Dema", age: 22 },
  { id: 1000000004, name: "Sukjai Dema", age: 23 },
  { id: 1000000005, name: "Sakasem Dema", age: 24 }
];

export default datas;